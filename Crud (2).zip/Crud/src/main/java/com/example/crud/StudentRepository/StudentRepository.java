package com.example.crud.StudentRepository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.crud.Entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
}

