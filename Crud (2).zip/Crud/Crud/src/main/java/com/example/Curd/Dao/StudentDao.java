package com.example.Curd.Dao;

public interface StudentDao {

}
