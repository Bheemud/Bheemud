package com.cg.exception;

public class ApplicationExeption extends RuntimeException {
	// TODO Auto-generated constructor stub
	public ApplicationExeption() {
		// TODO Auto-generated constructor stub
	}

	public ApplicationExeption(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
